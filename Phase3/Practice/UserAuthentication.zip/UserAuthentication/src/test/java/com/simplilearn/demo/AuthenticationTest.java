package com.simplilearn.demo;

import static org.junit.Assert.*;


import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;

public class AuthenticationTest {
	private Authentication auc;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}
	@Before
	public void setup() {
		auc = new Authentication();
		System.out.println("Login Initiated");
	}
	
	@After
	public void tearDown() {
		auc = null;
		System.out.println("Login Closed");
	}
	@Test
	public void aucTest1() {
		assertEquals(true,auc.authentication("keerthana","keerthi@123"));
		
	}
	
	@Test
	public void aucTest2() {
		assertEquals(true,auc.authentication("keerthana","keerthi@123"));
	}
	
	@Test
	public void aucTest3() {
		assertEquals(false,auc.authentication("bujji","keerthi@123"));
	}
	
	@Test
	public void aucTest4() {
		assertEquals(false,auc.authentication("thana","abjsfudfbc"));
	}
	@Test
	public void aucTest5() {
		assertEquals(false,auc.authentication("bhanu","bujjixyx"));
	}
	@Test
	public void aucTest6() {
		assertEquals(false,auc.authentication("keerthana","kjgierhgo"));
	}
}