package com.simplilearn.demo;

import java.util.Scanner;

public class Authentication{
	
	public boolean authentication(String username,String password) {
		if(username=="keerthana"& password=="keerthi@123") {
			return true;
		}
		else {
			return false;
		}
	}
}