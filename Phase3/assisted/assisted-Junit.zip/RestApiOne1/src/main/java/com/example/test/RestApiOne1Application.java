package com.example.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiOne1Application {

	public static void main(String[] args) {
		SpringApplication.run(RestApiOne1Application.class, args);
	}

}
