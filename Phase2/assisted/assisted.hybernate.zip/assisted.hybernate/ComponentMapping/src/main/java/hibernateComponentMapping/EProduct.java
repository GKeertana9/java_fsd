package hibernateComponentMapping;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.Map;


import java.math.BigDecimal;
import java.util.Date;

public class EProduct {
	
	private int ID;
	private String name;
	private BigDecimal price;
	private int quantity;
	private ProductsParts parts;
	
	//generate ctr+space;
	public EProduct() {
		// TODO Auto-generated constructor stub
	}

	public long getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public ProductsParts getParts() {
		return parts;
	}

	public void setParts(ProductsParts parts) {
		this.parts = parts;
	}
	
	

}