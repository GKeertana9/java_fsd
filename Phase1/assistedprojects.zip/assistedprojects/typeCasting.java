package assistedprojects;

public class typeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//implicit conversion
				System.out.println("Implicit Type Casting");
				byte a=30;
				System.out.println("Value of a: "+a);
				
				int b=a;
				System.out.println("Value of b: "+b);
				
				float c=a;
				System.out.println("Value of c: "+c);
				
				long d=a;
				System.out.println("Value of d: "+d);
				
				double e=a;
				System.out.println("Value of e: "+e);
				
				short f=a;
				System.out.println("Value of f: "+f);
				
						
				System.out.println("\n");
				
				System.out.println("Explicit Type Casting");
				//explicit conversion
				
				double x=45.5;
				System.out.println("Value of x: "+x);
				int y=(int)x;			
				
				System.out.println("Value of y: "+y);
				float z=(float)y;
				System.out.println("Value of z: "+z);
				long l=(long)z;
				System.out.println("Value of l: "+l);
				

	}

}
