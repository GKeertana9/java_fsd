package assistedprojects;

//public class Method {
//}

	class X {
		int a,b,i,j;
		void test()
		{
			System.out.println("No Arguments");
		}
		void op(int x,int y)
		{
			a=(x+y);
			b=(x*y);
			System.out.println("Addition: "+a);
			System.out.println("Multiplication: "+b);
		}
		void result()
		{
			System.out.println("value of i is :"+i);
			System.out.println("Value of j is "+j);
		}

	}
	class Method{
		public static void main(String args[])
		{
			X obj=new X();
			obj.test();
			obj.op(15,7);
			obj.i=25;
			obj.j=74;
			obj.result();
		}
	}


