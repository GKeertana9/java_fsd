package assistedprojects;

//public class constructor {
//}
	public class constructor {
		int x;
		float y;
		double z,t,rh;
		constructor(){
			
		}
		constructor(int s){
			x=(s*s);
		}
		constructor(float l, float b){
			y=(l*b);	
		}
		constructor(double r){
			z=(3.14*r*r);
		}
		void displaySquare(){
			System.out.println("area of square is " +x);
		}
		void displayRect(){
			System.out.println("area of rectangle is " +y);
		}
		void displayCircle(){
			System.out.println("area of circle is " +z);
		}
		void area(float k, float l){
			t=(0.5*k*l);
			System.out.println("area of triangle is " +t);
		} 
		void area(double d1, double d2){
			rh=(0.5*d1*d2);
			System.out.println("area of rhombus is " +rh);
		}
		

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			constructor s1=new constructor(5);
			constructor s2=new constructor(4,3);
			constructor s3=new constructor(4.7);
			constructor s4=new constructor();
			constructor s5=new constructor();
			s1.displaySquare();
			s2.displayRect();
			s3.displayCircle();
			s4.area(7.8,12);
			s5.area(13,9);
			
		}

	}
