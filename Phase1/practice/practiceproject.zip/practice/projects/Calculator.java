package practice.projects;
import java.util.Scanner;
public class Calculator {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double n1, n2, res=0;
		int x;
		do
                            {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number n1");
		n1=sc.nextDouble();
		System.out.println("Enter the number n2");
		n2=sc.nextDouble();
		System.out.println("Enter your choice from following Arthematic operations");
		System.out.println("The Arithematic operations are : ");
		System.out.println(" 1. + \n 2. - \n 3. * \n 4. / \n 5. exit]");
		x=sc.nextInt();
		switch (x) {
		case 1:	res = n1+n2;
                          		System.out.println("The sum of the given numbers is : " + res);
		              break;
		



                               case 2: res = n1-n2;
			System.out.println("The difference between the given numbers is : " + res);
			break;
		case 3:	res = n1 * n2;
			System.out.println("The product of the given numbers is : " + res);
			break;
		case 4:	if(n2!=0) {
				res = n1 / n2;
				System.out.println("The division of the given numbers is : " + res);
			} else {
				System.out.println("The denominator cannot be zero");
			}
		                 break;
		case 5: break;
		default: 
			System.out.println("Invalid Choice!");
		}
		System.out.println("Do you want to continue?\n 1.Yes\n 2.No");
		res=sc.nextDouble();
		}while(res==1);
                }
}
