package practice.projects;
import java.util.Scanner;
public class emailverification {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=0,i;		
				String array[]={"keerthi.garapati123@gmail.com",
						"keertana5b6@sasi.ac.in",
						"keerthana12001@outlook.com",
						"meghanagarapati33@gmail.com",
						"bujji2121@gmail.com",
						"sirisha156@gmial.com",
						"john@gmail.com",
						"keerthi@yahoo.com",
						"thomas.kiran@yahoo.com",
						"karthi@hotmail.com",
						"wahaj@gmail.com"};
			    Scanner sc = new Scanner(System.in);
			    System.out.println("Enter Email");
			    String b = sc.nextLine();
			    boolean f=false;
			



	
			for(i=0;i<array.length;i++){
				if(b.equals(array[i])){
					a=i;
					f=true;
					break;
				}
			}
			if(f==true){
				System.out.println("email found at "+i+" index in array");
			}
			else{
				System.out.println("Email not found !!!");
			}
			}
	}


