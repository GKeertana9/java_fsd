package practice.projects;

import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class Read {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[] array =new char[100];
		
		try{
			
		FileReader f=new FileReader("C:\\Users\\dell\\Downloads\\simplelearn\\Data.txt");
			
			f.read(array);
			System.out.println("Data presented in file is: ");
			System.out.println(array);
			f.close();
		}
		catch(Exception e){
			e.getStackTrace();
		}
	}

}

