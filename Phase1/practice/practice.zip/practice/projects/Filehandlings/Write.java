package practice.projects;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class Write {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Data ");
		 String data = sc.nextLine();
		try{
                             FileWriter f=new FileWriter("C:\\Users\\dell\\Downloads\\simplelearn\\Data.txt");
		f.write(data);
		System.out.println("Data was written into the file successfully");
		f.close();
		}
		catch(Exception e){
			e.getStackTrace();
		}
	}
}
